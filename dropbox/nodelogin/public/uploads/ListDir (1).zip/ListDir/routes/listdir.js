var fs = require('fs');
var ejs = require('ejs');
var testFolder = './routes/';

function listdir(req,res)
{
	var response = "";
	testFolder = req.param('dir');
	console.log(testFolder);
	fs.readdir(testFolder, function (err, files) 
	{
		console.log(files.length);
		console.log(files);
		for(var i=0;i<files.length;i++)
		{
			response += files[i]+"<br>";
		}
		res.send(response);
	});
}

function loadDirPage(req,res)
{
	ejs.renderFile('./views/ListDir.ejs',function(err, result) {
		if (!err) {
			res.end(result);
		}
		else {
			res.end('An error occurred');
			console.log(err);
		}
	});
	
	//res.render("ListDir");
}

exports.listdir = listdir;
exports.loadDirPage = loadDirPage;